@extends('layout')

@section('title')
    home
@endsection

@section('content')
    home
@endsection